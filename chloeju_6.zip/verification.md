# Assignment 06 — Verification Log

## 1.0 Collaboration episode

I asked Codex:

> Draft a Python function that classifies a movie using its rating and the joined runtime for a movie-night recommendation. Include a high-rating cutoff and a runtime window.

The initial draft was:

```python
def classify(movie, detail):
    if movie["vote_average"] >= 7.5 and 80 <= detail["runtime"] <= 120:
        return "movie-night fit"
    return "other"
```

I rejected this as incomplete. It combines the rating and runtime correctly, but it judges `vote_average` without a `vote_count` grounding guard. It would also put a movie with a perfect rating from one voter into the fit category. It does not have a separate under-evidence branch, so it cannot explain the difference between a weakly rated movie and a highly rated movie with too little evidence.

I accepted the general shape of the condition and corrected it to:

```python
if movie["vote_count"] < 500:
    return "Not enough evidence"
elif movie["vote_average"] >= 7.5 and 80 <= detail["runtime"] <= 120:
    return "Grounded movie-night fit"
else:
    return "Grounded but outside the fit"
```

The corrected version reaches the intended fields: `vote_count` supplies the grounding guard, `vote_average` supplies the quality boundary, and `runtime` comes from the joined detail record. The draft does not use `genre_ids`, so no genre decoding is needed for this decision. The `if`/`elif`/`else` order makes the evidence check happen before the rating check and makes every record reachable.

## 2.0 Independent data checks

I ran the submitted script with:

```text
uv run python modules/module_06/work/decide.py
```

The relevant output was:

```text
Movie records: 1500
Detail records: 1500
Distinct movie ids: 1475
Distinct detail ids: 1475
Duplicate detail ids checked: 25
Duplicate detail rows identical: True
Combined movie records: 1500
Uncombined movie records: 0
Vote count below 500: 675
Vote count at least 500: 825
Comparison threshold 300: 900 at least
Comparison threshold 750: 727 at least
Category counts:
  Grounded movie-night fit: 24
  Grounded but outside the fit: 801
  Not enough evidence: 675
```

I verified the join structurally by checking every movie ID against the detail lookup. The successful count was 1,500 and the missing count was 0. I counted the distinct IDs in both files and confirmed 1,475 in each. I grouped the detail records by ID and compared every row in each duplicate group with the first row; all 25 duplicate groups were exact copies. I therefore used one canonical detail row per ID while retaining all 1,500 movie rows in the classification.

I verified the threshold counts by counting the `vote_count` values directly from `movies.json`: 675 were below 500 and 825 were at least 500. I checked that the three category counts sum to 1,500. I checked sample records printed from each category against the source files, including *Obsession* as a fit, *Backrooms* as grounded but outside the fit, and *The Devil's Mouth* as not enough evidence. For each sample I compared the title, `vote_average`, `vote_count`, and joined `runtime`.

For the threshold comparison, the same direct count gave 900 records at or above 300 votes and 727 at or above 750 votes. These checks support the trade-off described in the report rather than relying on a copied classroom threshold.

## 3.0 Named edge-case checks

I opened the source record for *A Haunted Romance* and confirmed `vote_average == 10.0` and `vote_count == 1`. Calling the corrected classifier on that record returned `Not enough evidence`, so the grounding guard works as intended.

I also checked the borderline record *Phantom of the Paradise*. The source movie record has a `vote_average` of 7.474 and `vote_count` of 762. Its matching detail record has a runtime of 92 minutes. It therefore passes the evidence and runtime checks but fails the `>= 7.5` rating boundary and is placed in `Grounded but outside the fit`.

## 4.0 What I accepted and changed

I accepted the AI draft's use of a joined runtime and a two-part fit condition. I changed the draft by adding the 500-vote grounding guard, adding a distinct under-evidence category, and retaining every source row so that the reported counts describe the supplied 1,500-record collection. The category totals and edge cases above were checked by the script and against the source files, not by asking Codex to confirm its own output.
