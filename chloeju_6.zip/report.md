# Assignment 06 — A Grounded Movie-Night Decision

## 1.0 Your decision

I designed a three-category classification scheme for choosing a horror movie for an ordinary movie night. It separates supported movies that fit a normal feature-length window, supported movies outside that window, and movies whose ratings are not yet well supported. This serves someone who wants a defensible evening choice without treating a small number of votes as consensus.

## 2.0 The criteria

The decision uses `vote_average` for the community's reported opinion and `vote_count` for the amount of evidence behind that opinion. It also uses `runtime` from `movie_details.json`, because the intended audience needs a movie that fits an ordinary movie-night schedule. I deliberately did not use genre decoding or release date: this is already a horror collection, and recency is not part of this particular decision.

In plain language, a record with fewer than 500 votes is **Not enough evidence**. Among the records with at least 500 votes, a movie is a **Grounded movie-night fit** when its rating is at least 7.5 and its runtime is between 80 and 120 minutes inclusive. The remaining sufficiently supported records are **Grounded but outside the fit**.

The Python conditions are:

```python
if movie["vote_count"] < 500:
    category = "Not enough evidence"
elif movie["vote_average"] >= 7.5 and 80 <= detail["runtime"] <= 120:
    category = "Grounded movie-night fit"
else:
    category = "Grounded but outside the fit"
```

The `and` joins rating and runtime because both quality evidence and a practical length are required for the first category. The first test must happen before the rating test so that a highly rated movie with too few votes cannot be presented as a trusted choice.

## 3.0 The second file, and what it cost

I joined `movie_details.json` to each `movies.json` record by the shared integer `id`. I grouped detail rows by `id`, checked the duplicate groups, and kept the first row as the canonical detail row only after checking that all 25 duplicated detail IDs contained exact duplicate rows. The lookup therefore has 1,475 distinct detail IDs. Every one of the 1,500 movie records found an ID in that lookup: 1,500 combined and 0 did not.

I kept duplicate movie records rather than silently deduplicating the collection, so my counts are counts of the 1,500 shipped records. The 25 duplicate IDs occur twice on each side. A few movie duplicates have tiny differences in `vote_average` or `vote_count`, so collapsing them would change what is counted. The detail rows were checked, not assumed, to be identical; the movie rows were left as supplied.

## 4.0 The grounding threshold, justified

My grounding condition is `movie["vote_count"] >= 500`. The data has 1,500 records: 675 have fewer than 500 votes and 825 have at least 500. For comparison, a threshold of 300 keeps 900 records, while 750 keeps 727. I chose 500 as a compromise between evidence and coverage. It removes 45% of the records from the trusted branch but leaves more than half available. A lower line accepts more fragile ratings; a higher line discards more usable films for a casual movie night.

The guard also handles the named outlier correctly. *A Haunted Romance* has a `vote_average` of 10.0 but only 1 vote. Since 1 is below 500, the program places it in **Not enough evidence** rather than allowing the perfect-looking average to recommend it.

## 5.0 The categories, defended

**Not enough evidence** means `vote_count < 500`. This is a designed trust boundary, not a claim that every movie below it is bad. It says that this decision will not treat a rating as dependable enough for a movie-night recommendation when too few people have voted.

**Grounded movie-night fit** means at least 500 votes, a rating of at least 7.5, and a runtime from 80 through 120 minutes. The 7.5 boundary requires a clearly positive rating without copying the class's 8.0-style example. The runtime window represents a practical evening length; longer films require a different time commitment. Both endpoints are included so that the boundary is predictable.

**Grounded but outside the fit** contains records that pass the evidence guard but fail either the rating or runtime condition. This category is useful because it does not pretend that every grounded movie is a fit for this particular context.

One borderline record is *Phantom of the Paradise*: it has a 7.474 average, 762 votes, and a 92-minute runtime. It satisfies the evidence and length tests but misses the 7.5 rating boundary by 0.026, so it is outside the fit. This shows that the cutoff is sensitive to small rating differences. It does not make the rule useless, but it reminds me that the categories are a decision aid rather than a precise measurement of movie quality.

## 6.0 How it runs

`decide.py` loads both JSON files, builds the checked detail lookup, and uses a `for movie in movies` loop to visit all 1,500 records. It retrieves the runtime, applies the conditions, and increments one category count. The transformation turns movie dictionaries into a labelled summary with counts and samples. It keeps every record because all IDs matched.

The algorithm has a traverse → decide → collect shape: traverse the movie list, decide one category for each movie, and collect the counts and samples. Repeating that process over the whole collection is what makes this a scheme rather than a judgment about one film.

## 7.0 Results and verification

The run produced 24 **Grounded movie-night fit**, 801 **Grounded but outside the fit**, and 675 **Not enough evidence** records. These sum to 1,500. I checked the first three samples printed for each category against both source files, including rating, vote count, and runtime. I also checked 1,500 successful ID lookups, 0 misses, and *A Haunted Romance* directly in `movies.json`.

## 8.0 AI critique and verification log

I asked Codex: “Draft a Python function that classifies a movie using its rating and the joined runtime for a movie-night recommendation. Include a high-rating cutoff and a runtime window.” The first draft used rating and runtime but no `vote_count` guard. It would have allowed *A Haunted Romance* to pass on 10.0 alone, so I rejected it.

I corrected the order so the `vote_count < 500` branch comes first, then checked that the code reads `vote_average`, `vote_count`, and the joined `runtime`, and that the `elif` structure makes all three categories reachable. I ran the corrected file against the shipped data, checked the 24/801/675 counts, checked that they sum to 1,500, and confirmed the named outlier is under-evidenced. The AI supplied a starting structure, but I accepted only the parts that survived those checks.

## 9.0 A wrong result

The first draft classified *A Haunted Romance* as a possible movie-night fit because its rating was 10.0 and its runtime was in the window. That result was surprising because it ignored the obvious lack of evidence. Adding the grounding branch before the quality branch moved it to **Not enough evidence**, which resolved the problem.

## 10.0 Assumptions and limits

The scheme assumes that `vote_average` and `vote_count` represent useful audience evidence, that 500 votes is reasonable for this collection, and that 80–120 minutes suits an ordinary movie night. It could mislead someone seeking a long or very short film, or a new film with fewer than 500 votes. Ratings also cannot capture personal taste or content warnings. I treated `release_date` and genre detail as out of scope because audience and time commitment were the focus.

## 11.0 Reflection

The hardest part was choosing a threshold that removed unreliable small samples without leaving too few movies to choose from. Running the scheme showed me that the runtime condition reduced the highly rated, well-supported set to only 24 records; reading the rule alone did not show that effect. One number I verified against the data rather than accepting from Codex was the 675 records below the 500-vote threshold.
