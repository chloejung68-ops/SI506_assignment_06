"""Classify the horror-movie records for a grounded movie-night decision."""

from collections import Counter, defaultdict
import json
from pathlib import Path


VOTE_THRESHOLD = 500
QUALITY_CUTOFF = 7.5
MIN_RUNTIME = 80
MAX_RUNTIME = 120


def load_json(path: Path):
    with path.open(encoding="utf-8") as file:
        return json.load(file)


def build_detail_lookup(details):
    """Keep one detail record per id after checking duplicate records."""
    grouped = defaultdict(list)
    for detail in details:
        grouped[detail["id"]].append(detail)

    duplicate_ids = [movie_id for movie_id, rows in grouped.items() if len(rows) > 1]
    duplicates_are_identical = all(
        all(row == rows[0] for row in rows[1:])
        for movie_id in duplicate_ids
        for rows in [grouped[movie_id]]
    )

    # The duplicate detail rows were checked and are exact copies, so the first
    # row is a safe canonical value for the lookup.
    lookup = {movie_id: rows[0] for movie_id, rows in grouped.items()}
    return lookup, duplicate_ids, duplicates_are_identical


def classify(movie, detail):
    """Return one of the three designed categories for one movie record."""
    if movie["vote_count"] < VOTE_THRESHOLD:
        return "Not enough evidence"

    is_movie_night_fit = (
        movie["vote_average"] >= QUALITY_CUTOFF
        and MIN_RUNTIME <= detail["runtime"] <= MAX_RUNTIME
    )
    if is_movie_night_fit:
        return "Grounded movie-night fit"
    return "Grounded but outside the fit"


def main():
    provided = Path(__file__).resolve().parents[1] / "data" / "provided"
    movies = load_json(provided / "movies.json")
    details = load_json(provided / "movie_details.json")
    detail_lookup, duplicate_ids, duplicates_are_identical = build_detail_lookup(details)

    combined_count = 0
    missing_ids = []
    category_counts = Counter()
    category_samples = defaultdict(list)

    for movie in movies:
        detail = detail_lookup.get(movie["id"])
        if detail is None:
            missing_ids.append(movie["id"])
            continue

        combined_count += 1
        category = classify(movie, detail)
        category_counts[category] += 1
        if len(category_samples[category]) < 3:
            category_samples[category].append(
                (movie["title"], movie["vote_average"], movie["vote_count"], detail["runtime"])
            )

    vote_counts = [movie["vote_count"] for movie in movies]
    outlier = next(movie for movie in movies if movie["title"] == "A Haunted Romance")

    assert not missing_ids
    assert combined_count == len(movies) == 1500
    assert sum(category_counts.values()) == len(movies)
    assert len(detail_lookup) == 1475
    assert len(duplicate_ids) == 25
    assert duplicates_are_identical
    assert classify(outlier, detail_lookup[outlier["id"]]) == "Not enough evidence"
    outlier_category = classify(outlier, detail_lookup[outlier["id"]])

    print(f"Movie records: {len(movies)}")
    print(f"Detail records: {len(details)}")
    print(f"Distinct movie ids: {len({movie['id'] for movie in movies})}")
    print(f"Distinct detail ids: {len(detail_lookup)}")
    print(f"Duplicate detail ids checked: {len(duplicate_ids)}")
    print(f"Duplicate detail rows identical: {duplicates_are_identical}")
    print(f"Combined movie records: {combined_count}")
    print(f"Uncombined movie records: {len(missing_ids)}")
    print(f"Vote count below {VOTE_THRESHOLD}: {sum(count < VOTE_THRESHOLD for count in vote_counts)}")
    print(f"Vote count at least {VOTE_THRESHOLD}: {sum(count >= VOTE_THRESHOLD for count in vote_counts)}")
    print(f"Comparison threshold 300: {sum(count >= 300 for count in vote_counts)} at least")
    print(f"Comparison threshold 750: {sum(count >= 750 for count in vote_counts)} at least")
    print("Category counts:")
    for category in ("Grounded movie-night fit", "Grounded but outside the fit", "Not enough evidence"):
        print(f"  {category}: {category_counts[category]}")
        for sample in category_samples[category]:
            print(f"    sample: {sample}")
    print(
        "Outlier check: "
        f"{outlier['title']} average={outlier['vote_average']} "
        f"votes={outlier['vote_count']} -> {outlier_category}"
    )


if __name__ == "__main__":
    main()
